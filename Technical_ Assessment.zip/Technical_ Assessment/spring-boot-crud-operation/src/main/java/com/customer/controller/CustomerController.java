package com.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.model.Customer;
import com.customer.service.CustomerService;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	/**
	 * creating a get mapping that retrieves all the customer detail from the
	 * database
	 */
	@GetMapping(path = "/", produces = "application/json")
	public List<Customer> getAllCustomers() {
		return customerService.getAllCustomer();
	}

	/** creating a get mapping that retrieves the detail of a specific customer */
	@GetMapping(path = "/{customernumber}", produces = "application/json")
	public Customer getCustomer(@PathVariable("customernumber") int customernumber) {
		return customerService.getCustomerByCustomerNumber(customernumber);
	}

	/** creating a delete mapping that deletes a specified customer */
	@DeleteMapping(path = "/{customernumber}")
	public void deleteCustomer(@PathVariable("customernumber") int customernumber) {
		customerService.deleteCustomer(customernumber);
	}

	/** creating post mapping that create customer detail */
	@PostMapping(path = "/", consumes = "application/json", produces = "application/json")
	public Customer saveCustomer(@RequestBody Customer customer) {
		customerService.saveOrUpdate(customer);
		return customer;
	}

	/** creating put mapping that updates the customer details */
	@PutMapping(path = "/{customernumber}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Customer> updateCustomer(@PathVariable("customernumber") int customernumber,
			@RequestBody Customer customer) {
		return customerService.updateCustomer(customer, customernumber);
	}
}

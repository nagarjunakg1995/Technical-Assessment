package com.customer.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.exception.ResourceNotFoundException;
import com.customer.model.Customer;
import com.customer.service.CustomerService;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	/**
	 * creating a get mapping that retrieves all the customer detail from the
	 * database
	 */
	@GetMapping(path = "/", produces = "application/json")
	public List<Customer> getAllCustomers() {
		return customerService.getAllCustomer();
	}

	/** creating a get mapping that retrieves the detail of a specific customer */
	@GetMapping(path = "/{customernumber}", produces = "application/json")
	public ResponseEntity<Customer> getCustomer(@PathVariable("customernumber") @Size(min = 1) int customernumber)
			throws ResourceNotFoundException {
		try {

			Customer customer = customerService.getCustomerByCustomerNumber(customernumber);
			return ResponseEntity.ok().body(customer);
		}

		catch (Exception e) {
			throw new ResourceNotFoundException("customer not found for this id :: " + customernumber);
		}

		
	}

	/** creating a delete mapping that deletes a specified customer */
	@DeleteMapping(path = "/{customernumber}")
	public void deleteCustomer(@PathVariable("customernumber")  @Size(min = 1) int customernumber) throws ResourceNotFoundException  {
		customerService.deleteCustomer(customernumber);
	}

	/** creating post mapping that create customer detail */
	@PostMapping(path = "/", consumes = "application/json", produces = "application/json")
	public Customer saveCustomer(@Valid @RequestBody Customer customer) {
		customerService.saveOrUpdate(customer);
		return customer;
	}

	/** creating put mapping that updates the customer details */
	@PutMapping(path = "/{customernumber}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Customer> updateCustomer(@PathVariable("customernumber") @Size(min = 1) int customernumber,
			@Valid @RequestBody Customer customer) throws ResourceNotFoundException  {
		return customerService.updateCustomer(customer, customernumber);
	}
}

package com.customer.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer")
public class Customer {

	@Id
	private int customernumber;
	private String firstName;
	private String lastName;
	private String address;

	public int getId() {
		return customernumber;
	}

	public void setId(int id) {
		this.customernumber = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [id=" + customernumber + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + "]";
	}

}

package com.customer.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer")
public class Customer {

	@Id
	private int customernumber;

	@NotBlank
	@Size(max = 50, message = "max  size should be 50")
	private String firstName;

	@Size(max = 50)
	private String lastName;

	@NotBlank(message = "should not be blank")
	@Size(max = 150)
	private String address;
	
	
	

	public Customer(int customernumber, @NotBlank @Size(max = 50, message = "max  size should be 50") String firstName,
			@Size(max = 50) String lastName,
			@NotBlank(message = "should not be blank") @Size(max = 150) String address) {
		super();
		this.customernumber = customernumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
	}

	public int getId() {
		return customernumber;
	}

	public void setId(int id) {
		this.customernumber = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [id=" + customernumber + ", firstName=" + firstName + ", lastName=" + lastName + ", address="
				+ address + "]";
	}

}

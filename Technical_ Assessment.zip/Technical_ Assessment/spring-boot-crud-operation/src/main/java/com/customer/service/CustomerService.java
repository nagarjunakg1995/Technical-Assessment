package com.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.customer.model.Customer;
import com.customer.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	/**
	 * getting all customers record by using the method findaAll() of
	 * MongoRepository
	 */
	public List<Customer> getAllCustomer() {
		log.debug("inside get all customer");
		List<Customer> customer = new ArrayList<Customer>();
		customerRepository.findAll().forEach(books1 -> customer.add(books1));
		return customer;
	}

	/**
	 * getting a specific customer by using the method findById() of MongoRepository
	 */
	public Customer getCustomerByCustomerNumber(int id) {
		return customerRepository.findById(id).get();
	}

	/** saving a specific record by using the method save() of MongoRepository */
	public void saveOrUpdate(Customer customer) {
		customerRepository.save(customer);
	}

	/**
	 * deleting a specific customer record by using the method deleteById() of
	 * MongoRepository
	 */
	public void deleteCustomer(int id) {
		customerRepository.deleteById(id);
	}

	/** updating a customer record */
	public ResponseEntity<Customer> updateCustomer(Customer customer, int customernumber) {

		Optional<Customer> customerdata = customerRepository.findById(customernumber);

		if (customerdata.isPresent()) {

			Customer updateCust = customerdata.get();

			updateCust.setAddress(customer.getAddress());
			updateCust.setFirstName(customer.getFirstName());
			customer.setLastName(customer.getLastName());

			return new ResponseEntity<>(customerRepository.save(customer), HttpStatus.OK);
		} else {

			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

}

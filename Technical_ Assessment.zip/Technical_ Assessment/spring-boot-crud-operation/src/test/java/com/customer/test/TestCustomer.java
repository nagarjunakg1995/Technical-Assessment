package com.customer.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.customer.model.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestCustomer extends SpringBootCrudOperationApplicationTests {

	@Autowired
	private WebApplicationContext webApplicationContext;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void testCustomer() throws Exception {
		mockMvc.perform(get("/")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.customernumber").value(1)).andExpect(jsonPath("$.firstName").value("Nagarjun"))
				.andExpect(jsonPath("$.lastName").value("KG")).andExpect(jsonPath("$.address").value("Bangalore"));

	}

	@Test
	public void getCustomerByCustomerNumber() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.get("/{customernumber}", 1).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(MockMvcResultMatchers.jsonPath("$.customernumber").value(1));
	}

	@Test
	public void creatCustomer() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.post("/")
				.content(asJsonString(new Customer(123, "firstName1", "lastName1", "address1")))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated()).andExpect(MockMvcResultMatchers.jsonPath("$.customernumber").exists());
	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@Test
	public void updateCustomer() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.put("/{customernumber}", 123)
				.content(asJsonString(new Customer(123, "firstName2", "lastName2", "address2")))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.firstName").value("firstName2"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.lastName").value("lastName2"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.address").value("address2"));
	}

	@Test
	public void deleteEmployeeAPI() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders.delete("/{customernumber}", 123)).andExpect(status().isAccepted());
	}

}
